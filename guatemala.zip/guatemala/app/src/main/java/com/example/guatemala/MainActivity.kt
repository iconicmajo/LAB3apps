package com.example.guatemala

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
    fun showtikal(view: View){
        var intent: Intent = Intent(this, activity_tikal::class.java)
        startActivity(intent)
    }
    fun showpana(view: View){
        var intent: Intent = Intent(this, activity_pana::class.java)
        startActivity(intent)
    }
    fun showantigua(view: View){
        var intent: Intent = Intent(this, activity_tikal::class.java)
        startActivity(intent)
    }

}
